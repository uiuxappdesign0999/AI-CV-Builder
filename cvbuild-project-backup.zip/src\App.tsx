import { useEffect, useMemo, useState } from 'react'
import {
  ArrowUpRight,
  Bell,
  Check,
  ChevronDown,
  ChevronRight,
  Download,
  FileText,
  FolderOpen,
  HelpCircle,
  Home,
  LayoutTemplate,
  Menu,
  MoreHorizontal,
  PenLine,
  Plus,
  Search,
  Sparkles,
  Trash2,
  UserRound,
  WandSparkles,
  X,
} from 'lucide-react'
import './App.css'

type Experience = {
  id: number
  role: string
  company: string
  date: string
  description: string
}

const templates = [
  { name: 'Modern', className: 'modern', color: '#496bff' },
  { name: 'Minimal', className: 'minimal', color: '#22252d' },
  { name: 'Creative', className: 'creative', color: '#eb6d4a' },
  { name: 'Executive', className: 'executive', color: '#4d947e' },
]

const initialExperience: Experience[] = [
  {
    id: 1,
    role: 'Senior Product Designer',
    company: 'Northstar Labs',
    date: 'Mar 2022 — Present',
    description:
      'Led the design of a B2B SaaS platform used by 20k+ customers. Partnered with product and engineering to ship a new onboarding flow that improved activation by 24%.',
  },
  {
    id: 2,
    role: 'Product Designer',
    company: 'Studio Arc',
    date: 'Jun 2019 — Feb 2022',
    description:
      'Designed end-to-end experiences across web and mobile. Established a scalable design system and mentored two junior designers.',
  },
]

function App() {
  const [activeNav, setActiveNav] = useState('Overview')
  const [activeTemplate, setActiveTemplate] = useState('Modern')
  const [showNewCv, setShowNewCv] = useState(false)
  const [showMobileNav, setShowMobileNav] = useState(false)
  const [showExperience, setShowExperience] = useState(false)
  const [showToast, setShowToast] = useState(false)
  const [cvName, setCvName] = useState(() => localStorage.getItem('smartcv.name') || 'Product Designer CV')
  const [summary, setSummary] = useState(() => localStorage.getItem('smartcv.summary') || 'Product designer with 7+ years of experience creating clear, intuitive digital products. I turn complex problems into simple, delightful experiences that help people do their best work.')
  const [experience, setExperience] = useState<Experience[]>(() => {
    const stored = localStorage.getItem('smartcv.experience')
    return stored ? JSON.parse(stored) as Experience[] : initialExperience
  })
  const [newExperience, setNewExperience] = useState({ role: '', company: '', date: '', description: '' })
  const [aiLoading, setAiLoading] = useState(false)
  const [accent, setAccent] = useState(() => localStorage.getItem('smartcv.accent') || '#496bff')
  const [editorTab, setEditorTab] = useState('Content')
  const [visibleSections, setVisibleSections] = useState<Record<string, boolean>>({ Summary: true, Experience: true, Education: true, Skills: true })

  useEffect(() => {
    localStorage.setItem('smartcv.name', cvName)
    localStorage.setItem('smartcv.summary', summary)
    localStorage.setItem('smartcv.experience', JSON.stringify(experience))
    localStorage.setItem('smartcv.accent', accent)
  }, [cvName, summary, experience, accent])

  const wordCount = useMemo(() => summary.trim().split(/\s+/).filter(Boolean).length, [summary])

  const notify = () => {
    setShowToast(true)
    window.setTimeout(() => setShowToast(false), 2600)
  }

  const generateSummary = () => {
    setAiLoading(true)
    window.setTimeout(() => {
      setSummary(
        'Product designer with 7+ years of experience shaping thoughtful digital products from first sketch to final pixel. I blend systems thinking, research, and craft to turn complex challenges into simple experiences that drive measurable growth.',
      )
      setAiLoading(false)
      notify()
    }, 850)
  }

  const addExperience = () => {
    if (!newExperience.role || !newExperience.company) return
    setExperience([...experience, { ...newExperience, id: Date.now() }])
    setNewExperience({ role: '', company: '', date: '', description: '' })
    setShowExperience(false)
  }

  const exportCv = () => {
    const data = {
      name: cvName,
      template: activeTemplate,
      accent,
      summary,
      experience,
      exportedAt: new Date().toISOString(),
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `${cvName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.json`
    link.click()
    URL.revokeObjectURL(url)
    notify()
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${showMobileNav ? 'sidebar-open' : ''}`}>
        <div className="brand"><span className="brand-mark"><Sparkles size={16} /></span><span>smart<span>cv</span></span></div>
        <button className="close-mobile" onClick={() => setShowMobileNav(false)}><X size={20} /></button>
        <div className="workspace-switcher"><div className="workspace-avatar">AM</div><div><b>Alex Morgan</b><span>Personal workspace</span></div><ChevronDown size={15} /></div>
        <nav>
          <p className="nav-label">Workspace</p>
          {[
            ['Overview', Home], ['My CVs', FolderOpen], ['Templates', LayoutTemplate],
          ].map(([label, Icon]) => (
            <button key={label as string} className={activeNav === label ? 'active' : ''} onClick={() => { setActiveNav(label as string); setShowMobileNav(false) }}>
              <Icon size={18} />{label as string}{label === 'My CVs' && <span className="nav-count">3</span>}
            </button>
          ))}
          <p className="nav-label nav-gap">Account</p>
          {[
            ['Profile settings', UserRound], ['Billing & plan', Sparkles], ['Help center', HelpCircle],
          ].map(([label, Icon]) => <button key={label as string} onClick={() => setActiveNav(label as string)} className={activeNav === label ? 'active' : ''}><Icon size={18} />{label as string}</button>)}
        </nav>
        <div className="sidebar-bottom"><div className="upgrade-card"><span className="upgrade-icon"><Sparkles size={15} /></span><b>Unlock your potential</b><p>Get unlimited AI help and premium templates.</p><button onClick={notify}>Explore Pro <ArrowUpRight size={14} /></button></div><div className="user-row"><div className="avatar">AM</div><div><b>Alex Morgan</b><span>Free plan</span></div><MoreHorizontal size={18} /></div></div>
      </aside>

      <main className="main-content">
        <header className="topbar"><button className="menu-button" onClick={() => setShowMobileNav(true)}><Menu size={21} /></button><div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14} /><b>{activeNav}</b></div><div className="top-actions"><button className="icon-button"><Search size={18} /></button><button className="icon-button notification"><Bell size={18} /><i /></button><div className="avatar avatar-small">AM</div></div></header>

        <div className="page">
          <div className="page-heading"><div><p className="eyebrow">Thursday, November 5, 2026</p><h1>Good morning, Alex <span>✦</span></h1><p className="subheading">Build a CV that gets you noticed.</p></div><button className="primary-button" onClick={() => setShowNewCv(true)}><Plus size={18} /> Create new CV</button></div>

          <section className="stats-grid">
            {[['3', 'CVs created', 'Keep your options open'], ['82%', 'Profile strength', 'You’re almost there'], ['12', 'AI assists used', 'This month']].map(([value, label, hint], i) => <div className="stat-card" key={label}><div className={`stat-icon stat-${i}`}><FileText size={18} /></div><div><strong>{value}</strong><b>{label}</b><span>{hint}</span></div>{i === 1 && <div className="progress-ring"><span>82</span></div>}</div>)}
          </section>

          <section className="section-header"><div><h2>Your CVs</h2><p>Manage and continue working on your resumes.</p></div><button className="text-button" onClick={() => setActiveNav('My CVs')}>View all <ArrowUpRight size={15} /></button></section>
          <section className="cv-grid">
            <div className="cv-card featured"><div className="cv-preview modern-preview" style={{ '--accent': accent } as React.CSSProperties}><div className="mini-name">Alex Morgan</div><div className="mini-role">PRODUCT DESIGNER</div><div className="mini-line" /><div className="mini-columns"><div><i /><i /><i /><i /></div><div><i /><i /><i /></div></div><span className="page-number">1 / 2</span></div><div className="cv-card-body"><div><h3>{cvName}</h3><span>Saved locally · just now</span></div><button className="more-button" onClick={notify}><MoreHorizontal size={18} /></button></div><div className="cv-card-actions"><button onClick={() => setActiveNav('Editor')}><PenLine size={15} /> Edit CV</button><button onClick={exportCv}><Download size={15} /> Export JSON</button><button onClick={() => window.print()}><FileText size={15} /> Print / PDF</button></div></div>
            <div className="new-cv-card" onClick={() => setShowNewCv(true)}><div className="plus-circle"><Plus size={22} /></div><b>Create a new CV</b><span>Start from a template or blank page</span></div>
          </section>

          <div className="content-columns">
            <section className="editor-card">
              <div className="section-header compact"><div><h2>Quick editor</h2><p>Make changes and see them live.</p></div><span className="saved"><Check size={14} /> Saved</span></div>
              <div className="editor-tabs">{['Content', 'Design', 'Sections'].map((tab) => <button key={tab} className={editorTab === tab ? 'active' : ''} onClick={() => setEditorTab(tab)}>{tab}</button>)}</div>
              {editorTab === 'Content' && <><div className="form-section"><label>Professional summary <span>{wordCount} words</span></label><div className="textarea-wrap"><textarea value={summary} onChange={(e) => setSummary(e.target.value)} /><button className="ai-button" onClick={generateSummary} disabled={aiLoading}><WandSparkles size={15} /> {aiLoading ? 'Writing...' : 'Improve with AI'}</button></div><p className="field-hint">A strong summary helps recruiters understand your value in seconds.</p></div>
              <div className="form-section"><div className="label-row"><label>Work experience</label><button className="add-link" onClick={() => setShowExperience(true)}><Plus size={15} /> Add experience</button></div>{experience.map((item) => <div className="experience-row" key={item.id}><div className="experience-dot" /><div><b>{item.role}</b><span>{item.company} · {item.date}</span></div><button className="delete-button" onClick={() => setExperience(experience.filter((entry) => entry.id !== item.id))}><Trash2 size={15} /></button></div>)}</div></>}
              {editorTab === 'Design' && <div className="design-panel"><label>Accent color</label><div className="color-options">{templates.map((template) => <button key={template.color} aria-label={`${template.name} color`} className={accent === template.color ? 'selected' : ''} style={{ background: template.color }} onClick={() => setAccent(template.color)} />)}</div><label>Template</label><div className="design-template-row">{templates.map((template) => <button key={template.name} className={activeTemplate === template.name ? 'selected' : ''} onClick={() => { setActiveTemplate(template.name); setAccent(template.color) }}>{template.name}<Check size={13} /></button>)}</div></div>}
              {editorTab === 'Sections' && <div className="sections-panel">{Object.keys(visibleSections).map((section) => <label key={section}><span>{section}</span><input type="checkbox" checked={visibleSections[section]} onChange={() => setVisibleSections({ ...visibleSections, [section]: !visibleSections[section] })} /></label>)}</div>}
              <button className="save-button" onClick={notify}>Save changes</button>
            </section>

            <section className="insights-card"><div className="insights-heading"><div className="sparkle-orb"><Sparkles size={18} /></div><div><h2>Smart insights</h2><p>Small improvements, big impact.</p></div></div><div className="insight-item"><div className="insight-check"><Check size={14} /></div><div><b>Great start</b><span>Your summary is clear and easy to scan.</span></div></div><div className="insight-item warning"><div className="insight-check"><span>!</span></div><div><b>Add more skills</b><span>Profiles with 8+ skills get 2× more views.</span></div><button onClick={notify}>Fix <ChevronRight size={14} /></button></div><div className="insight-item"><div className="insight-check"><Check size={14} /></div><div><b>ATS friendly</b><span>Your current template is optimized for screening.</span></div></div><div className="tips-footer"><Sparkles size={15} /> <span>Tip: Use numbers to show the impact of your work.</span></div></section>
          </div>

          <section className="templates-section"><div className="section-header"><div><h2>Explore templates</h2><p>Make a great first impression with a design that feels like you.</p></div><button className="text-button" onClick={() => setActiveNav('Templates')}>Browse templates <ArrowUpRight size={15} /></button></div><div className="template-row">{templates.map((template) => <button className={`template-card ${activeTemplate === template.name ? 'selected' : ''}`} key={template.name} onClick={() => { setActiveTemplate(template.name); setAccent(template.color); notify() }}><div className={`template-thumb ${template.className}`}><div className="thumb-head" /><div className="thumb-body\"><i /><i /><i /><i /><i /></div></div><span>{template.name}</span>{activeTemplate === template.name && <span className="selected-check"><Check size={11} /></span>}</button>)}</div></section>
        </div>
      </main>

      {showNewCv && <div className="modal-backdrop" onClick={() => setShowNewCv(false)}><div className="modal" onClick={(e) => e.stopPropagation()}><button className="modal-close" onClick={() => setShowNewCv(false)}><X size={18} /></button><div className="modal-icon"><FileText size={22} /></div><h2>Create a new CV</h2><p>Give your CV a name and choose a starting point.</p><label>CV name<input value={cvName} onChange={(e) => setCvName(e.target.value)} placeholder="e.g. Product Designer CV" /></label><label>Start with<select><option>Modern template</option><option>Minimal template</option><option>Creative template</option><option>Blank CV</option></select></label><button className="primary-button full" onClick={() => { setShowNewCv(false); notify() }}>Create CV <ArrowUpRight size={16} /></button></div></div>}
      {showExperience && <div className="modal-backdrop" onClick={() => setShowExperience(false)}><div className="modal experience-modal" onClick={(e) => e.stopPropagation()}><button className="modal-close" onClick={() => setShowExperience(false)}><X size={18} /></button><div className="modal-icon"><BriefcaseIcon /></div><h2>Add experience</h2><p>Add a role and make your experience stand out.</p><label>Job title<input value={newExperience.role} onChange={(e) => setNewExperience({ ...newExperience, role: e.target.value })} placeholder="Senior Product Designer" /></label><label>Company<input value={newExperience.company} onChange={(e) => setNewExperience({ ...newExperience, company: e.target.value })} placeholder="Company name" /></label><div className="split-fields"><label>Dates<input value={newExperience.date} onChange={(e) => setNewExperience({ ...newExperience, date: e.target.value })} placeholder="2022 — Present" /></label><label>Location<input placeholder="Remote" /></label></div><label>What did you achieve?<textarea value={newExperience.description} onChange={(e) => setNewExperience({ ...newExperience, description: e.target.value })} placeholder="Describe your impact..." /></label><button className="primary-button full" onClick={addExperience}>Add experience <Plus size={16} /></button></div></div>}
      {showToast && <div className="toast"><Check size={16} /> Changes saved successfully</div>}
    </div>
  )
}

function BriefcaseIcon() {
  return <span className="briefcase-icon">✦</span>
}

export default App
